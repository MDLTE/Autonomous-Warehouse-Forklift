"""
botoni_main.launch.py
=====================
Launch principal — corre en la PC de Marcelo.

Nodos que levanta:
  1. botoni_fsm_node       — FSM principal (este paquete)
  2. rosbridge_websocket   — WebSocket para el dashboard React  (:9090)
  3. web_video_server      — Stream de cámara para el dashboard (:8080)
  4. web_server (http)     — Sirve el dashboard React            (:5173 via vite)

Nodos EXTERNOS que deben estar corriendo ANTES de este launch:
  - Jetson: base.launch.py (cámara, lidar, hackerboard, goto_altura_v8)
  - Marcelo: slam_node, nav_node_pb, aruco_detector, poseKalman, alignment_node
  - Diego:   voice_node (WebSocket :9091), logo_detector

Uso:
  ros2 launch botoni_main botoni_main.launch.py

Parámetros opcionales:
  ros2 launch botoni_main botoni_main.launch.py web_port:=5173 bridge_port:=9090
"""

from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    ExecuteProcess,
    LogInfo,
    RegisterEventHandler,
    TimerAction,
)
from launch.event_handlers import OnProcessExit, OnProcessStart
from launch.substitutions import LaunchConfiguration, FindExecutable
from launch_ros.actions import Node
import os


def generate_launch_description():

    # ── Argumentos configurables ──────────────────────────────
    bridge_port_arg = DeclareLaunchArgument(
        'bridge_port', default_value='9090',
        description='Puerto de rosbridge WebSocket'
    )
    video_port_arg = DeclareLaunchArgument(
        'video_port', default_value='8080',
        description='Puerto de web_video_server'
    )
    web_port_arg = DeclareLaunchArgument(
        'web_port', default_value='5173',
        description='Puerto del servidor web del dashboard'
    )

    bridge_port = LaunchConfiguration('bridge_port')
    video_port  = LaunchConfiguration('video_port')
    web_port    = LaunchConfiguration('web_port')

    # ── 1. FSM principal ──────────────────────────────────────
    fsm_node = Node(
        package='botoni_main',
        executable='botoni_fsm',
        name='botoni_master',
        output='screen',                   # Imprime en terminal
        emulate_tty=True,                  # Colores ANSI en terminal
        parameters=[{
            'use_sim_time': False,
        }],
        remappings=[
            # Si Marcelo usa nombres distintos para nav, se mapean aquí:
            # ('/nav_goal', '/puzzle_nav/goal'),
        ],
    )

    # ── 2. rosbridge_websocket ────────────────────────────────
    rosbridge_node = Node(
        package='rosbridge_server',
        executable='rosbridge_websocket',
        name='rosbridge_websocket',
        output='screen',
        parameters=[{
            'port': bridge_port,
            'address': '0.0.0.0',           # Acepta conexiones externas
            'retry_startup_delay': 2.0,
            'fragment_timeout': 600,
            'delay_between_messages': 0,
            'max_message_size': 10000000,   # 10 MB para el mapa SLAM
            'unregister_timeout': 10.0,
            'use_compression': False,
        }],
    )

    # ── 3. web_video_server ───────────────────────────────────
    web_video_node = Node(
        package='web_video_server',
        executable='web_video_server',
        name='web_video_server',
        output='screen',
        parameters=[{
            'port': video_port,
            'address': '0.0.0.0',
        }],
    )

    # ── 4. Dashboard React (Vite) ─────────────────────────────
    #    Asume que el build está en ~/botoni_ui/
    #    Si ya está buildeado: python3 -m http.server --directory dist
    #    Si está en dev: npm run dev -- --host
    dashboard_dir = os.path.expanduser('~/botoni_ui')

    # Intenta correr el servidor de producción (dist/) primero
    # Si no existe dist, corre el dev server
    dist_dir = os.path.join(dashboard_dir, 'dist')
    if os.path.isdir(dist_dir):
        dashboard_server = ExecuteProcess(
            cmd=[
                'python3', '-m', 'http.server',
                LaunchConfiguration('web_port'),
                '--directory', dist_dir,
                '--bind', '0.0.0.0',
            ],
            name='dashboard_server',
            output='screen',
            cwd=dashboard_dir,
        )
    else:
        dashboard_server = ExecuteProcess(
            cmd=[
                'npm', 'run', 'dev', '--',
                '--host', '0.0.0.0',
                '--port', LaunchConfiguration('web_port'),
            ],
            name='dashboard_dev_server',
            output='screen',
            cwd=dashboard_dir,
        )

    # ── Logs de inicio ────────────────────────────────────────
    log_start = LogInfo(
        msg=[
            '\n',
            '╔══════════════════════════════════════════════════╗\n',
            '║           BOTONI — Sistema iniciando             ║\n',
            '╠══════════════════════════════════════════════════╣\n',
            '║  FSM        → /fsm_state  /fsm_mission           ║\n',
            '║  rosbridge  → ws://0.0.0.0:', bridge_port, '             ║\n',
            '║  video      → http://0.0.0.0:', video_port, '           ║\n',
            '║  dashboard  → http://0.0.0.0:', web_port, '            ║\n',
            '╚══════════════════════════════════════════════════╝\n',
        ]
    )

    log_prereqs = LogInfo(
        msg=[
            '\n[PREREQS] Asegúrate de que estos nodos ya corren:\n'
            '  Jetson  : base.launch.py, goto_altura_v8.py\n'
            '  Marcelo : slam_node, nav_node_pb, aruco_detector\n'
            '            poseKalman, alignment_node\n'
            '  Diego   : voice_node (:9091), logo_detector\n'
        ]
    )

    return LaunchDescription([
        # Argumentos
        bridge_port_arg,
        video_port_arg,
        web_port_arg,

        # Logs
        log_prereqs,
        log_start,

        # Nodos en orden
        rosbridge_node,
        web_video_node,
        fsm_node,
        dashboard_server,
    ])
