#!/usr/bin/env python3
"""
botoni_fsm_node.py
==================
Nodo principal de Botoni — corre en la PC de Marcelo.
Máquina de estados completa con control STOP/PAUSE/START.

Arquitectura de topics
───────────────────────
PUBLICA:
  /fsm_state        std_msgs/String      — estado actual (para UI)
  /fsm_mission      std_msgs/String      — JSON completo (estado, misión, step, log)
  /cmd_vel          geometry_msgs/Twist  — cero en STOP/PAUSE
  /fork_cmd         std_msgs/String      — nombre de altura destino
  /nav_goal         std_msgs/String      — JSON {waypoint, type}
  /alignment_start  std_msgs/String      — JSON {type, target}

SUSCRIBE:
  /fork_done        std_msgs/Bool        — confirmación de altura alcanzada
  /fork_height      std_msgs/Float32     — altura actual en mm
  /nav_status       std_msgs/String      — "arrived" | "failed"
  /alignment_done   std_msgs/String      — "success" | "failed"
  /aruco/detections std_msgs/String      — JSON con detecciones
  /qr/detections    std_msgs/String      — JSON con detecciones
  /voice_cmd        std_msgs/String      — comandos de voz
  /ui_cmd           std_msgs/String      — JSON {action, payload}
"""

import rclpy
import json
import time
import threading
from enum import Enum, auto
from rclpy.node import Node
from std_msgs.msg import String, Bool, Float32
from geometry_msgs.msg import Twist


# ─────────────────────────────────────────────
#  ESTADOS DE LA FSM
# ─────────────────────────────────────────────
class State(Enum):
    # ── Control ──────────────────────────────
    STOP           = auto()   # Estado inicial/reset. Robot quieto, fork abajo.
    IDLE           = auto()   # Esperando misión seleccionada + START
    PAUSED         = auto()   # Congelado, recuerda estado anterior
    ERROR          = auto()   # Fallo — requiere STOP manual

    # ── Búsqueda de origen ───────────────────
    SEARCH_LOADING = auto()   # Visita Loading A→B→C buscando QR empresa
    SEARCH_RACK    = auto()   # Visita Rack1-Rack3, puntos A→F buscando pallet

    # ── Navegación hacia origen ──────────────
    NAV_TO_SOURCE  = auto()   # Navega al waypoint de origen encontrado/seleccionado

    # ── Alineamiento ─────────────────────────
    ALIGN_SOURCE   = auto()   # alignment_node.py alinea con QR/ArUco en origen

    # ── Recogida de pallet ───────────────────
    FORK_ENTER_GET = auto()   # Baja fork a altura_entrada (loading o rack)
    FORK_GRAB_GET  = auto()   # Sube fork a altura_agarre para levantar pallet
    REVERSE_GET    = auto()   # Dead reckoning: retrocede ~35 cm con pallet

    # ── Navegación hacia destino ─────────────
    SEARCH_TRUCK   = auto()   # Visita Truck A→B→C buscando logo empresa
    NAV_TO_DEST    = auto()   # Navega al waypoint de truck encontrado

    # ── Alineamiento destino ──────────────────
    ALIGN_DEST     = auto()   # alignment_node.py alinea con ArUco en truck

    # ── Depósito de pallet ───────────────────
    FORK_ENTER_PUT = auto()   # Avanza al interior del truck
    FORK_DROP_PUT  = auto()   # Baja fork a punto_bajo para depositar
    REVERSE_PUT    = auto()   # Dead reckoning: retrocede

    # ── Fin de misión ─────────────────────────
    MISSION_DONE   = auto()   # Éxito — vuelve a IDLE al presionar START


# ─────────────────────────────────────────────
#  MISIONES
# ─────────────────────────────────────────────
class Mission(Enum):
    NONE           = "none"
    LOADING_TRUCK  = "loading_truck"   # Loading dock → Truck
    RACK_TRUCK     = "rack_truck"      # Rack → Truck


# ─────────────────────────────────────────────
#  ALTURAS DEL FORK
# ─────────────────────────────────────────────
FORK_HEIGHTS = {
    "punto_alto":          1,
    "rack_arriba_agarre":  2,
    "rack_arriba_entrada": 3,
    "loading_agarre":      4,
    "loading_entrada":     5,
    "rack_abajo_agarre":   6,
    "rack_abajo_entrada":  7,
    "punto_bajo":          8,
}

# Alturas según tipo de operación
HEIGHT_MAP = {
    "loading_get_enter": "loading_entrada",
    "loading_get_grab":  "loading_agarre",
    "rack_abajo_get_enter": "rack_abajo_entrada",
    "rack_abajo_get_grab":  "rack_abajo_agarre",
    "rack_arriba_get_enter": "rack_arriba_entrada",
    "rack_arriba_get_grab":  "rack_arriba_agarre",
    "truck_put_enter":   "loading_agarre",   # llega con el pallet en agarre
    "truck_put_drop":    "punto_bajo",
}

# ─────────────────────────────────────────────
#  WAYPOINTS DE BÚSQUEDA
# ─────────────────────────────────────────────
SEARCH_SEQUENCE = {
    Mission.LOADING_TRUCK: {
        "source_search": [
            "waypoint_G_Loading_A",
            "waypoint_G_Loading_B",
            "waypoint_G_Loading_C",
        ],
        "dest_search": [
            "waypoint_P_Truck_A",
            "waypoint_P_Truck_B",
            "waypoint_P_Truck_C",
        ],
    },
    Mission.RACK_TRUCK: {
        "source_search": [
            "waypoint_G_Rack_1_A", "waypoint_G_Rack_1_B", "waypoint_G_Rack_1_C",
            "waypoint_G_Rack_1_D", "waypoint_G_Rack_1_E", "waypoint_G_Rack_1_F",
            "waypoint_G_Rack_2_A", "waypoint_G_Rack_2_B", "waypoint_G_Rack_2_C",
            "waypoint_G_Rack_2_D", "waypoint_G_Rack_2_E", "waypoint_G_Rack_2_F",
            "waypoint_G_Rack_3_A", "waypoint_G_Rack_3_B", "waypoint_G_Rack_3_C",
            "waypoint_G_Rack_3_D", "waypoint_G_Rack_3_E", "waypoint_G_Rack_3_F",
        ],
        "dest_search": [
            "waypoint_P_Truck_A",
            "waypoint_P_Truck_B",
            "waypoint_P_Truck_C",
        ],
    },
}


# ─────────────────────────────────────────────
#  NODO PRINCIPAL
# ─────────────────────────────────────────────
class BotoniMaster(Node):

    def __init__(self):
        super().__init__('botoni_master')

        self.get_logger().info("=" * 55)
        self.get_logger().info("  BOTONI MASTER — iniciando")
        self.get_logger().info("=" * 55)

        # ── Estado de la FSM ──────────────────────────────────
        self._state       = State.STOP
        self._prev_state  = None          # para PAUSE/RESUME
        self._mission     = Mission.NONE
        self._target_co   = None          # empresa seleccionada (ej. "EMEZON")
        self._step        = 0             # sub-step dentro del estado actual
        self._log         = "Sistema listo. Selecciona misión y presiona START."

        # ── Contexto de misión en curso ───────────────────────
        self._search_idx       = 0        # índice en la lista de waypoints de búsqueda
        self._found_source_wp  = None     # waypoint de origen encontrado
        self._found_dest_wp    = None     # waypoint de destino encontrado
        self._source_type      = None     # "loading" | "rack_abajo" | "rack_arriba"

        # ── Banderas de sincronía ─────────────────────────────
        self._fork_done_flag       = threading.Event()
        self._nav_arrived_flag     = threading.Event()
        self._nav_failed_flag      = threading.Event()
        self._alignment_done_flag  = threading.Event()
        self._alignment_fail_flag  = threading.Event()
        self._detection_found      = None   # payload JSON de la detección

        # ── Mutex para acceso seguro al estado ───────────────
        self._lock = threading.Lock()

        # ── Thread de ejecución de la FSM ────────────────────
        self._fsm_thread = None
        self._running    = False

        # ── Publishers ───────────────────────────────────────
        self.pub_fsm_state    = self.create_publisher(String, '/fsm_state',    10)
        self.pub_fsm_mission  = self.create_publisher(String, '/fsm_mission',  10)
        self.pub_cmd_vel      = self.create_publisher(Twist,  '/cmd_vel',      10)
        self.pub_fork_cmd     = self.create_publisher(String, '/fork_cmd',     10)
        self.pub_nav_goal     = self.create_publisher(String, '/nav_goal',     10)
        self.pub_align_start  = self.create_publisher(String, '/alignment_start', 10)

        # ── Subscribers ──────────────────────────────────────
        self.create_subscription(Bool,   '/fork_done',        self._cb_fork_done,    10)
        self.create_subscription(Float32,'/fork_height',      self._cb_fork_height,  10)
        self.create_subscription(String, '/nav_status',       self._cb_nav_status,   10)
        self.create_subscription(String, '/alignment_done',   self._cb_align_done,   10)
        self.create_subscription(String, '/aruco/detections', self._cb_aruco,        10)
        self.create_subscription(String, '/qr/detections',    self._cb_qr,           10)
        self.create_subscription(String, '/voice_cmd',        self._cb_voice,        10)
        self.create_subscription(String, '/ui_cmd',           self._cb_ui_cmd,       10)

        # ── Timer de publicación periódica del estado ─────────
        self.create_timer(0.2, self._publish_state)

        # ── Publicar estado inicial ───────────────────────────
        self._set_state(State.STOP)
        self._publish_state()
        self.get_logger().info("[STOP] Robot en reposo. Esperando misión.")


    # ─────────────────────────────────────────
    #  CALLBACKS SUBSCRIBERS
    # ─────────────────────────────────────────

    def _cb_fork_done(self, msg):
        if msg.data:
            self._fork_done_flag.set()

    def _cb_fork_height(self, msg):
        pass  # disponible para logging si se necesita

    def _cb_nav_status(self, msg):
        if msg.data == "arrived":
            self._nav_arrived_flag.set()
        elif msg.data == "failed":
            self._nav_failed_flag.set()

    def _cb_align_done(self, msg):
        if msg.data == "success":
            self._alignment_done_flag.set()
        else:
            self._alignment_fail_flag.set()

    def _cb_aruco(self, msg):
        """Guarda detección de ArUco si estamos buscando."""
        if self._state in (State.SEARCH_RACK, State.SEARCH_TRUCK):
            try:
                data = json.loads(msg.data)
                if data.get("detections"):
                    self._detection_found = data
            except Exception:
                pass

    def _cb_qr(self, msg):
        """Guarda detección de QR si estamos buscando."""
        if self._state in (State.SEARCH_LOADING, State.SEARCH_TRUCK):
            try:
                data = json.loads(msg.data)
                if data.get("detections"):
                    # Filtra por empresa si hay una seleccionada
                    if self._target_co:
                        for d in data["detections"]:
                            if self._target_co.upper() in str(d.get("data", "")).upper():
                                self._detection_found = data
                                return
                    else:
                        self._detection_found = data
            except Exception:
                pass

    def _cb_voice(self, msg):
        """Mapea comandos de voz a acciones de control."""
        cmd = msg.data.upper().strip()
        self.get_logger().info(f"[VOICE] Comando recibido: {cmd}")
        if cmd in ("START", "INICIO", "GO"):
            self._handle_start()
        elif cmd in ("STOP", "ALTO", "PARA"):
            self._handle_stop()
        elif cmd in ("PAUSE", "PAUSA"):
            self._handle_pause()
        elif cmd in ("LOADING", "CARGA"):
            self._mission = Mission.LOADING_TRUCK
            self._log = "Misión seleccionada: LOADING → TRUCK"
            self.get_logger().info("[IDLE] Misión: LOADING_TRUCK")
        elif cmd in ("RACK", "ESTANTE"):
            self._mission = Mission.RACK_TRUCK
            self._log = "Misión seleccionada: RACK → TRUCK"
            self.get_logger().info("[IDLE] Misión: RACK_TRUCK")

    def _cb_ui_cmd(self, msg):
        """Procesa comandos del dashboard React."""
        try:
            data = json.loads(msg.data)
            action  = data.get("action", "")
            payload = data.get("payload", {})
        except Exception:
            return

        if action == "START":
            self._handle_start()
        elif action == "STOP":
            self._handle_stop()
        elif action == "PAUSE":
            self._handle_pause()
        elif action == "SELECT_MISSION":
            m = payload.get("mission", "")
            if m == "loading_truck":
                self._mission = Mission.LOADING_TRUCK
                self._log = "Misión: LOADING → TRUCK"
                self.get_logger().info("[CONFIG] Misión LOADING_TRUCK seleccionada")
            elif m == "rack_truck":
                self._mission = Mission.RACK_TRUCK
                self._log = "Misión: RACK → TRUCK"
                self.get_logger().info("[CONFIG] Misión RACK_TRUCK seleccionada")
        elif action == "SELECT_COMPANY":
            self._target_co = payload.get("company", None)
            self.get_logger().info(f"[CONFIG] Empresa objetivo: {self._target_co}")


    # ─────────────────────────────────────────
    #  CONTROL: STOP / PAUSE / START
    # ─────────────────────────────────────────

    def _handle_stop(self):
        """STOP: para todo, fork a punto_bajo, vuelve a IDLE."""
        self.get_logger().info("[CMD] ── STOP recibido ──────────────────────")
        with self._lock:
            self._running = False

        # 1. Parar motores inmediatamente
        self._send_zero_vel()
        self.get_logger().info("[STOP] Motores detenidos.")

        # 2. Fork a punto_bajo
        self._set_state(State.STOP)
        self.get_logger().info("[STOP] Enviando fork a punto_bajo...")
        self._send_fork("punto_bajo")
        self._fork_done_flag.clear()
        # Espera máx 10 s para que el fork llegue
        if not self._fork_done_flag.wait(timeout=10.0):
            self.get_logger().warn("[STOP] Timeout esperando fork — continuando de todas formas")
        self.get_logger().info("[STOP] Fork en punto_bajo.")

        # 3. Reset de contexto de misión
        self._reset_mission_context()

        # 4. Ir a IDLE
        self._set_state(State.IDLE)
        self._log = "Sistema en reposo. Selecciona misión y presiona START."
        self.get_logger().info("[IDLE] Listo para nueva misión.")

    def _handle_pause(self):
        """PAUSE: snapshot del estado, para movimiento sin perder contexto."""
        if self._state in (State.STOP, State.IDLE, State.PAUSED, State.ERROR):
            self.get_logger().warn(f"[PAUSE] Ignorado — estado actual: {self._state.name}")
            return

        self.get_logger().info("[CMD] ── PAUSE recibido ─────────────────────")
        with self._lock:
            self._running = False
            self._prev_state = self._state

        self._send_zero_vel()
        self._set_state(State.PAUSED)
        self._log = f"Pausado en: {self._prev_state.name}. START para continuar."
        self.get_logger().info(f"[PAUSED] Snapshot guardado: {self._prev_state.name}")

    def _handle_start(self):
        """START: desde PAUSED reanuda, desde IDLE inicia misión."""
        if self._state == State.PAUSED:
            self.get_logger().info("[CMD] ── START (reanudar) ───────────────")
            self._set_state(self._prev_state)
            self._log = f"Reanudando desde: {self._state.name}"
            self.get_logger().info(f"[RESUME] Continuando en estado: {self._state.name}")
            self._start_fsm_thread()

        elif self._state == State.IDLE:
            if self._mission == Mission.NONE:
                self.get_logger().warn("[START] No hay misión seleccionada. Elige una primero.")
                self._log = "⚠ Sin misión. Selecciona LOADING o RACK primero."
                return
            self.get_logger().info(f"[CMD] ── START misión: {self._mission.value} ──")
            self._log = f"Iniciando misión: {self._mission.value}"
            self._set_state(
                State.SEARCH_LOADING if self._mission == Mission.LOADING_TRUCK
                else State.SEARCH_RACK
            )
            self._start_fsm_thread()

        else:
            self.get_logger().warn(f"[START] Ignorado — estado actual: {self._state.name}")


    # ─────────────────────────────────────────
    #  FSM THREAD
    # ─────────────────────────────────────────

    def _start_fsm_thread(self):
        with self._lock:
            if self._fsm_thread and self._fsm_thread.is_alive():
                self._running = False
                self._fsm_thread.join(timeout=2.0)
            self._running = True
            self._fsm_thread = threading.Thread(target=self._fsm_loop, daemon=True)
            self._fsm_thread.start()

    def _fsm_loop(self):
        """Bucle principal de la máquina de estados."""
        self.get_logger().info("[FSM] Thread iniciado.")
        try:
            while rclpy.ok() and self._running:
                state = self._state

                if state == State.SEARCH_LOADING:
                    self._run_search_loading()
                elif state == State.SEARCH_RACK:
                    self._run_search_rack()
                elif state == State.NAV_TO_SOURCE:
                    self._run_nav_to_source()
                elif state == State.ALIGN_SOURCE:
                    self._run_align_source()
                elif state == State.FORK_ENTER_GET:
                    self._run_fork_enter_get()
                elif state == State.FORK_GRAB_GET:
                    self._run_fork_grab_get()
                elif state == State.REVERSE_GET:
                    self._run_reverse_get()
                elif state == State.SEARCH_TRUCK:
                    self._run_search_truck()
                elif state == State.NAV_TO_DEST:
                    self._run_nav_to_dest()
                elif state == State.ALIGN_DEST:
                    self._run_align_dest()
                elif state == State.FORK_ENTER_PUT:
                    self._run_fork_enter_put()
                elif state == State.FORK_DROP_PUT:
                    self._run_fork_drop_put()
                elif state == State.REVERSE_PUT:
                    self._run_reverse_put()
                elif state == State.MISSION_DONE:
                    self._run_mission_done()
                    break
                elif state in (State.STOP, State.IDLE, State.PAUSED, State.ERROR):
                    break
                else:
                    break

                if not self._running:
                    break

        except Exception as e:
            self.get_logger().error(f"[FSM] Excepción: {e}")
            self._set_state(State.ERROR)
            self._log = f"Error: {e}"

        self.get_logger().info("[FSM] Thread terminado.")


    # ─────────────────────────────────────────
    #  ESTADOS DE LA FSM — implementación
    # ─────────────────────────────────────────

    def _run_search_loading(self):
        seq = SEARCH_SEQUENCE[Mission.LOADING_TRUCK]["source_search"]
        self.get_logger().info(f"[SEARCH_LOADING] Iniciando búsqueda en {len(seq)} puntos de loading")
        self._log = "Buscando pallet en Loading docks..."

        for wp in seq:
            if not self._running:
                return

            self.get_logger().info(f"[SEARCH_LOADING] → Navegando a {wp}")
            self._log = f"Buscando pallet... waypoint: {wp}"
            self._detection_found = None
            self._nav_to(wp)
            if not self._wait_nav():
                return

            # Espera detección QR hasta 3 s
            self.get_logger().info(f"[SEARCH_LOADING] @ {wp} — escaneando QR...")
            deadline = time.time() + 3.0
            while time.time() < deadline and self._running:
                if self._detection_found:
                    break
                time.sleep(0.1)

            if self._detection_found:
                self._found_source_wp = wp
                self._source_type = "loading"
                self.get_logger().info(f"[SEARCH_LOADING] ✓ Pallet encontrado en {wp}")
                self._log = f"Pallet encontrado en {wp}"
                self._set_state(State.ALIGN_SOURCE)
                return

        # No encontró nada
        self.get_logger().error("[SEARCH_LOADING] ✗ No se encontró pallet. ERROR.")
        self._log = "ERROR: No se encontró pallet en loading docks"
        self._set_state(State.ERROR)

    def _run_search_rack(self):
        seq = SEARCH_SEQUENCE[Mission.RACK_TRUCK]["source_search"]
        self.get_logger().info(f"[SEARCH_RACK] Iniciando búsqueda en {len(seq)} puntos de rack")
        self._log = "Buscando pallet en racks..."

        for wp in seq:
            if not self._running:
                return

            self.get_logger().info(f"[SEARCH_RACK] → Navegando a {wp}")
            self._log = f"Buscando pallet... waypoint: {wp}"
            self._detection_found = None
            self._nav_to(wp)
            if not self._wait_nav():
                return

            # Escanea tanto rack_arriba como rack_abajo desde este punto
            self.get_logger().info(f"[SEARCH_RACK] @ {wp} — escaneando ArUco rack arriba/abajo...")
            deadline = time.time() + 2.0
            while time.time() < deadline and self._running:
                if self._detection_found:
                    break
                time.sleep(0.1)

            if self._detection_found:
                self._found_source_wp = wp
                # Determina si es rack_arriba o rack_abajo del payload
                det = self._detection_found
                rack_level = det.get("rack_level", "rack_abajo")
                self._source_type = rack_level
                self.get_logger().info(f"[SEARCH_RACK] ✓ Pallet {rack_level} en {wp}")
                self._log = f"Pallet encontrado ({rack_level}) en {wp}"
                self._set_state(State.ALIGN_SOURCE)
                return

        self.get_logger().error("[SEARCH_RACK] ✗ No se encontró pallet. ERROR.")
        self._log = "ERROR: No se encontró pallet en racks"
        self._set_state(State.ERROR)

    def _run_nav_to_source(self):
        # Usado cuando el waypoint ya se conoce (skip búsqueda)
        self.get_logger().info(f"[NAV_TO_SOURCE] → {self._found_source_wp}")
        self._log = f"Navegando a origen: {self._found_source_wp}"
        self._nav_to(self._found_source_wp)
        if not self._wait_nav():
            return
        self._set_state(State.ALIGN_SOURCE)

    def _run_align_source(self):
        self.get_logger().info("[ALIGN_SOURCE] Iniciando alineamiento con pallet origen")
        self._log = "Alineando con pallet en origen..."
        self._do_alignment("source", self._source_type)
        if not self._wait_alignment():
            return
        self.get_logger().info("[ALIGN_SOURCE] ✓ Alineado con origen")
        self._set_state(State.FORK_ENTER_GET)

    def _run_fork_enter_get(self):
        height_key = f"{self._source_type}_get_enter"
        height = HEIGHT_MAP.get(height_key, "loading_entrada")
        self.get_logger().info(f"[FORK_ENTER_GET] Fork → {height} (entrar al pallet)")
        self._log = f"Fork bajando a altura entrada: {height}"
        self._send_fork(height)
        if not self._wait_fork(timeout=15.0):
            return
        self.get_logger().info(f"[FORK_ENTER_GET] ✓ Fork en {height}")
        # Avance corto para meter forks bajo el pallet (dead reckoning ~20cm)
        self._drive_straight(dist_m=0.20, speed=0.1)
        self._set_state(State.FORK_GRAB_GET)

    def _run_fork_grab_get(self):
        height_key = f"{self._source_type}_get_grab"
        height = HEIGHT_MAP.get(height_key, "loading_agarre")
        self.get_logger().info(f"[FORK_GRAB_GET] Fork → {height} (agarrar pallet)")
        self._log = f"Fork subiendo a altura agarre: {height}"
        self._send_fork(height)
        if not self._wait_fork(timeout=15.0):
            return
        self.get_logger().info(f"[FORK_GRAB_GET] ✓ Pallet levantado en {height}")
        self._set_state(State.REVERSE_GET)

    def _run_reverse_get(self):
        self.get_logger().info("[REVERSE_GET] Retrocediendo con pallet (~35 cm)")
        self._log = "Retrocediendo con pallet..."
        self._drive_straight(dist_m=-0.35, speed=0.1)
        time.sleep(0.5)
        self.get_logger().info("[REVERSE_GET] ✓ Retirado del origen")
        self._set_state(State.SEARCH_TRUCK)

    def _run_search_truck(self):
        seq = SEARCH_SEQUENCE[self._mission]["dest_search"]
        self.get_logger().info(f"[SEARCH_TRUCK] Buscando truck en {len(seq)} puntos")
        self._log = "Buscando truck destino..."

        for wp in seq:
            if not self._running:
                return

            self.get_logger().info(f"[SEARCH_TRUCK] → Navegando a {wp}")
            self._log = f"Buscando truck... waypoint: {wp}"
            self._detection_found = None
            self._nav_to(wp)
            if not self._wait_nav():
                return

            self.get_logger().info(f"[SEARCH_TRUCK] @ {wp} — escaneando logo empresa...")
            deadline = time.time() + 3.0
            while time.time() < deadline and self._running:
                if self._detection_found:
                    break
                time.sleep(0.1)

            if self._detection_found:
                self._found_dest_wp = wp
                self.get_logger().info(f"[SEARCH_TRUCK] ✓ Truck encontrado en {wp}")
                self._log = f"Truck encontrado en {wp}"
                self._set_state(State.ALIGN_DEST)
                return

        self.get_logger().error("[SEARCH_TRUCK] ✗ No se encontró truck. ERROR.")
        self._log = "ERROR: No se encontró truck destino"
        self._set_state(State.ERROR)

    def _run_nav_to_dest(self):
        self.get_logger().info(f"[NAV_TO_DEST] → {self._found_dest_wp}")
        self._log = f"Navegando a destino: {self._found_dest_wp}"
        self._nav_to(self._found_dest_wp)
        if not self._wait_nav():
            return
        self._set_state(State.ALIGN_DEST)

    def _run_align_dest(self):
        self.get_logger().info("[ALIGN_DEST] Alineando con truck destino")
        self._log = "Alineando con truck destino..."
        self._do_alignment("dest", "truck")
        if not self._wait_alignment():
            return
        self.get_logger().info("[ALIGN_DEST] ✓ Alineado con truck")
        self._set_state(State.FORK_ENTER_PUT)

    def _run_fork_enter_put(self):
        # Avance corto para entrar al truck
        self.get_logger().info("[FORK_ENTER_PUT] Avanzando al interior del truck (~25 cm)")
        self._log = "Avanzando al interior del truck..."
        self._drive_straight(dist_m=0.25, speed=0.1)
        self._set_state(State.FORK_DROP_PUT)

    def _run_fork_drop_put(self):
        self.get_logger().info("[FORK_DROP_PUT] Fork → punto_bajo (depositar pallet)")
        self._log = "Depositando pallet: fork a punto_bajo..."
        self._send_fork("punto_bajo")
        if not self._wait_fork(timeout=15.0):
            return
        self.get_logger().info("[FORK_DROP_PUT] ✓ Pallet depositado")
        self._set_state(State.REVERSE_PUT)

    def _run_reverse_put(self):
        self.get_logger().info("[REVERSE_PUT] Retrocediendo del truck (~30 cm)")
        self._log = "Saliendo del truck..."
        self._drive_straight(dist_m=-0.30, speed=0.1)
        time.sleep(0.3)
        self.get_logger().info("[REVERSE_PUT] ✓ Fuera del truck")
        self._set_state(State.MISSION_DONE)

    def _run_mission_done(self):
        self.get_logger().info("=" * 55)
        self.get_logger().info("  ✓ MISIÓN COMPLETADA")
        self.get_logger().info("=" * 55)
        self._log = "✓ Misión completada. Presiona START para nueva misión."
        self._set_state(State.MISSION_DONE)
        # Vuelve a IDLE automáticamente después de 3 s
        time.sleep(3.0)
        self._reset_mission_context()
        self._set_state(State.IDLE)


    # ─────────────────────────────────────────
    #  HELPERS — publicación y espera
    # ─────────────────────────────────────────

    def _send_zero_vel(self):
        self.pub_cmd_vel.publish(Twist())

    def _send_fork(self, height_name: str):
        msg = String()
        msg.data = height_name
        self.pub_fork_cmd.publish(msg)
        self._fork_done_flag.clear()
        self.get_logger().info(f"  ↳ /fork_cmd → {height_name}")

    def _nav_to(self, waypoint: str):
        msg = String()
        msg.data = json.dumps({"waypoint": waypoint})
        self.pub_nav_goal.publish(msg)
        self._nav_arrived_flag.clear()
        self._nav_failed_flag.clear()
        self.get_logger().info(f"  ↳ /nav_goal → {waypoint}")

    def _do_alignment(self, role: str, atype: str):
        msg = String()
        msg.data = json.dumps({
            "role": role,
            "type": atype,
            "target_company": self._target_co,
        })
        self.pub_align_start.publish(msg)
        self._alignment_done_flag.clear()
        self._alignment_fail_flag.clear()
        self.get_logger().info(f"  ↳ /alignment_start → role={role} type={atype}")

    def _wait_fork(self, timeout=15.0) -> bool:
        """Espera fork_done. Retorna False si fue interrumpido o timeout."""
        while self._running:
            if self._fork_done_flag.wait(timeout=0.2):
                return True
            timeout -= 0.2
            if timeout <= 0:
                self.get_logger().warn("  [WAIT] Timeout esperando fork_done")
                return True  # continúa de todas formas (no bloquea la misión)
        return False

    def _wait_nav(self, timeout=60.0) -> bool:
        while self._running:
            if self._nav_arrived_flag.wait(timeout=0.2):
                return True
            if self._nav_failed_flag.is_set():
                self.get_logger().error("  [WAIT] Navegación falló")
                self._set_state(State.ERROR)
                self._log = "ERROR: Navegación falló"
                return False
            timeout -= 0.2
            if timeout <= 0:
                self.get_logger().warn("  [WAIT] Timeout navegación — continuando")
                return True
        return False

    def _wait_alignment(self, timeout=30.0) -> bool:
        while self._running:
            if self._alignment_done_flag.wait(timeout=0.2):
                return True
            if self._alignment_fail_flag.is_set():
                self.get_logger().error("  [WAIT] Alineamiento falló")
                self._set_state(State.ERROR)
                self._log = "ERROR: Alineamiento falló"
                return False
            timeout -= 0.2
            if timeout <= 0:
                self.get_logger().warn("  [WAIT] Timeout alineamiento — continuando")
                return True
        return False

    def _drive_straight(self, dist_m: float, speed: float = 0.1):
        """Dead reckoning: avanza/retrocede por tiempo estimado."""
        if not self._running:
            return
        duration = abs(dist_m) / speed
        twist = Twist()
        twist.linear.x = speed if dist_m > 0 else -speed
        t0 = time.time()
        rate = 0.05
        while time.time() - t0 < duration and self._running:
            self.pub_cmd_vel.publish(twist)
            time.sleep(rate)
        self._send_zero_vel()


    # ─────────────────────────────────────────
    #  HELPERS — estado y publicación
    # ─────────────────────────────────────────

    def _set_state(self, new_state: State):
        self._state = new_state
        self._publish_state()

    def _publish_state(self):
        # /fsm_state — string simple para compatibilidad
        s_msg = String()
        s_msg.data = self._state.name
        self.pub_fsm_state.publish(s_msg)

        # /fsm_mission — JSON completo para el dashboard
        m_msg = String()
        m_msg.data = json.dumps({
            "state":   self._state.name,
            "mission": self._mission.value,
            "target":  self._target_co,
            "log":     self._log,
            "source_wp": self._found_source_wp,
            "dest_wp":   self._found_dest_wp,
            "source_type": self._source_type,
        })
        self.pub_fsm_mission.publish(m_msg)

    def _reset_mission_context(self):
        self._search_idx      = 0
        self._found_source_wp = None
        self._found_dest_wp   = None
        self._source_type     = None
        self._detection_found = None
        self._prev_state      = None
        self._fork_done_flag.clear()
        self._nav_arrived_flag.clear()
        self._nav_failed_flag.clear()
        self._alignment_done_flag.clear()
        self._alignment_fail_flag.clear()


# ─────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────

def main(args=None):
    rclpy.init(args=args)
    node = BotoniMaster()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("[SHUTDOWN] Ctrl+C — deteniendo Botoni Master")
        node._handle_stop()
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
